let Entity = require('./Entity');
let Dog = require('./Dog');
let Person = require('./Person');
let Student = require('./Student');

result.Entity = Entity;
result.Person = Person;
result.Dog = Dog;
result.Student = Student;
